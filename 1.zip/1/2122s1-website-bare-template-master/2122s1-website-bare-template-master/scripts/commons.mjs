export const DEFAULTS = {
    duration: 3, // minutes
};